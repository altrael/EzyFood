package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyFoodOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_food_order);

        Intent i = getIntent();
        int quantity_miegoreng = i.getIntExtra("quantity_miegoreng1", 0);
        int quantity_hakao = i.getIntExtra("quantity_hakao1", 0);
        int quantity_siomay = i.getIntExtra("quantity_siomay1", 0);
        int quantity_nasigoreng = i.getIntExtra("quantity_nasigoreng1", 0);

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        int total_harga = (quantity_miegoreng*15000) + (quantity_hakao*10000) + (quantity_siomay*12000) + (quantity_nasigoreng*15000);

        String Total = "Total = Rp. "+total_harga;
        total.setText(Total);

        // Mie Goreng
        TextView miegoreng = findViewById(R.id.qtymiegoreng);
        String friednoodle = "Qty "+quantity_miegoreng+" x 15000";
        miegoreng.setText(friednoodle);

        // Hakao
        TextView hakao = findViewById(R.id.qtyhakao);
        String hakaos = "Qty "+quantity_hakao+" x 10000";
        hakao.setText(hakaos);

        // Siomay
        TextView siomay = findViewById(R.id.qtysiomay);
        String shumai = "Qty "+quantity_siomay+" x 12000";
        siomay.setText(shumai);

        // Nasi Goreng
        TextView nasigoreng = findViewById(R.id.qtynasigoreng);
        String friedrice = "Qty "+quantity_nasigoreng+" x 10000";
        nasigoreng.setText(friedrice);

        // Button Hapus

        Button hapus_miegoreng = (Button) findViewById(R.id.hapusmiegoreng);
        Button hapus_hakao = (Button) findViewById(R.id.hapushakao);
        Button hapus_siomay= (Button) findViewById(R.id.hapussiomay);
        Button hapus_nasigoreng = (Button) findViewById(R.id.hapusnasigoreng);

        hapus_miegoreng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_miegoreng = 0;
                TextView miegoreng = (TextView) findViewById(R.id.qtymiegoreng);
                String friednoodle = "Qty "+quantity_miegoreng+" x 15000";
                miegoreng.setText(friednoodle);

            }
        });
        hapus_hakao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_hakao = 0;
                TextView hakao = (TextView) findViewById(R.id.qtyhakao);
                String hakaos = "Qty "+quantity_hakao+" x 10000";
                hakao.setText(hakaos);
            }
        });

        hapus_siomay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_siomay = 0;
                TextView siomay = (TextView) findViewById(R.id.qtysiomay);
                String shumai = "Qty "+quantity_siomay+" x 12000";
                siomay.setText(shumai);
            }
        });

        hapus_nasigoreng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_nasigoreng = 0;
                TextView nasigoreng = (TextView) findViewById(R.id.qtynasigoreng);
                String friedrice = "Qty "+quantity_nasigoreng+" x 15000";
                nasigoreng.setText(friedrice);
            }
        });
    }

    public void showMyFoodOrderComplete(View view){
        Button btn4 = (Button) findViewById(R.id.payButton);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MyFoodOrder.this,FoodOrderComplete.class);

                TextView miegoreng = (TextView) findViewById(R.id.qtymiegoreng);
                TextView hakao = (TextView) findViewById(R.id.qtyhakao);
                TextView siomay = (TextView) findViewById(R.id.qtysiomay);
                TextView nasigoreng = (TextView) findViewById(R.id.qtynasigoreng);

                TextView total = (TextView) findViewById(R.id.textView_total);

                i.putExtra("harga_miegoreng", miegoreng.getText());
                i.putExtra("harga_hakao", hakao.getText());
                i.putExtra("harga_siomay", siomay.getText());
                i.putExtra("harga_nasigoreng", nasigoreng.getText());


                i.putExtra("total_harga", total.getText());
                startActivity(i);
            }
        });
    }
}