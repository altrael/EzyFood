package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MySnackOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_snack_order);

        Intent i = getIntent();
        int quantity_potato = i.getIntExtra("quantity_potato1", 0);
        int quantity_nachos = i.getIntExtra("quantity_nachos1", 0);
        int quantity_chicken = i.getIntExtra("quantity_chicken1", 0);
        int quantity_chasew = i.getIntExtra("quantity_chasew1", 0);

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        int total_harga = (quantity_potato*5000) + (quantity_nachos*10000) + (quantity_chicken*12000) + (quantity_chasew*10000);

        String Total = "Total = Rp. "+total_harga;
        total.setText(Total);

        // Potato Chips
        TextView potato = findViewById(R.id.qtypotato);
        String potater = "Qty "+quantity_potato+" x 5000";
        potato.setText(potater);

        // Nachos
        TextView nachos = findViewById(R.id.qtynachos);
        String nacho = "Qty "+quantity_nachos+" x 10000";
        nachos.setText(nacho);

        // Chicken Skin
        TextView chicken = findViewById(R.id.qtychicken);
        String chickens = "Qty "+quantity_chicken+" x 12000";
        chicken.setText(chickens);

        // Chasew Nut
        TextView chasew = findViewById(R.id.qtychasew);
        String chasews = "Qty "+quantity_chasew+" x 10000";
        chasew.setText(chasews);

        // Button Hapus

        Button hapus_potato = (Button) findViewById(R.id.hapuspotato);
        Button hapus_nachos = (Button) findViewById(R.id.hapusnachos);
        Button hapus_chicken= (Button) findViewById(R.id.hapuschicken);
        Button hapus_chasew = (Button) findViewById(R.id.hapuschasew);

        hapus_potato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_potato = 0;
                TextView potato = (TextView) findViewById(R.id.qtypotato);
                String potatos = "Qty "+quantity_potato+" x 5000";
                potato.setText(potatos);

            }
        });
        hapus_nachos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_nachos = 0;
                TextView nachos = (TextView) findViewById(R.id.qtynachos);
                String nacho = "Qty "+quantity_nachos+" x 10000";
                nachos.setText(nacho);
            }
        });

        hapus_chicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_chicken = 0;
                TextView chicken = (TextView) findViewById(R.id.qtychicken);
                String chickens = "Qty "+quantity_chicken+" x 12000";
                chicken.setText(chickens);
            }
        });

        hapus_chasew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_chasew = 0;
                TextView chasew = (TextView) findViewById(R.id.qtychasew);
                String chasews = "Qty "+quantity_chasew+" x 10000";
                chasew.setText(chasews);
            }
        });
    }

    public void showMySnackOrderComplete(View view){
        Button btn4 = (Button) findViewById(R.id.payButton);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MySnackOrder.this,SnackOrderComplete.class);

                TextView potato = (TextView) findViewById(R.id.qtypotato);
                TextView nachos = (TextView) findViewById(R.id.qtynachos);
                TextView chicken = (TextView) findViewById(R.id.qtychicken);
                TextView chasew = (TextView) findViewById(R.id.qtychasew);

                TextView total = (TextView) findViewById(R.id.textView_total);

                i.putExtra("harga_potato", potato.getText());
                i.putExtra("harga_nachos", nachos.getText());
                i.putExtra("harga_chicken", chicken.getText());
                i.putExtra("harga_chasew", chasew.getText());


                i.putExtra("total_harga", total.getText());
                startActivity(i);
            }
        });
    }
}