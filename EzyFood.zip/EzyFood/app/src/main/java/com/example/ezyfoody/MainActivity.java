package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.os.Bundle;
import android.view.*;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showDrink(View view){
        FrameLayout frame1 = (FrameLayout) findViewById(R.id.frameLayout1);
        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,MenuDrink.class);
                startActivity(i);
            }
        });
    }

    public void showFood(View view){
        FrameLayout frame1 = (FrameLayout) findViewById(R.id.frameLayout3);
        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,MenuFood.class);
                startActivity(i);
            }
        });
    }

    public void showSnack(View view){
        FrameLayout frame1 = (FrameLayout) findViewById(R.id.frameLayout2);
        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,MenuSnack.class);
                startActivity(i);
            }
        });
    }

    public void showTopUp(View view){
        FrameLayout frame1 = (FrameLayout) findViewById(R.id.frameLayout4);
        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,TopUp.class);
                String saldo = i.getStringExtra("saldo");
                i.putExtra("saldo1", saldo);
                startActivity(i);
            }
        });
    }

    public void showMyOrder(View view){
        Button btn1 = (Button) findViewById(R.id.orderButton);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,MyOrder.class);
                startActivity(i);
            }
        });
    }
}