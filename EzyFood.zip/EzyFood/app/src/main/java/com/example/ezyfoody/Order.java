package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Order extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        CardView card  = (CardView) findViewById(R.id.order_air);
        CardView card1 = (CardView) findViewById(R.id.order_apel);
        CardView card2 = (CardView) findViewById(R.id.order_mangga);
        CardView card3 = (CardView) findViewById(R.id.order_alpukat);

        Intent intent = getIntent();
        Integer opsi = intent.getIntExtra("option", 0);

        if(opsi == 0){
            card.setVisibility(View.VISIBLE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 1){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.VISIBLE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 2){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.VISIBLE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 3){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.VISIBLE);
        }
    }

    public void showMyOrder2(View view){
        Button btn3 = (Button) findViewById(R.id.orderButton3);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(Order.this, MyOrder.class);

                if(opsi == 0){
                    String quantity_air = quantity.getText().toString();
                    int int_quantity_air = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_air = Integer.parseInt(quantity_air)+get_quantity_air;

                    i.putExtra("quantity_air1", int_quantity_air);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else if(opsi == 1){
                    String quantity_apel = quantity.getText().toString();
                    int int_quantity_apel = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_apel = Integer.parseInt(quantity_apel)+get_quantity_apel;

                    i.putExtra("quantity_apel1", int_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else if(opsi == 2){
                    String quantity_mangga = quantity.getText().toString();
                    int int_quantity_mangga = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_mangga = Integer.parseInt(quantity_mangga)+get_quantity_mangga;

                    i.putExtra("quantity_mangga1", int_quantity_mangga);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else{
                    String quantity_alpukat = quantity.getText().toString();
                    int int_quantity_alpukat = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_alpukat = Integer.parseInt(quantity_alpukat)+get_quantity_alpukat;

                    i.putExtra("quantity_alpukat1", int_quantity_alpukat);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_air1", get_quantity_air);
                }
                startActivity(i);
            }
        });
    }

    public void showMyAlternativeOrder(View view){
        Button btn3 = (Button) findViewById(R.id.orderAlternativeButton2);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(Order.this, MyOrder.class);
                if(opsi == 0){
                    String quantity_air = quantity.getText().toString();
                    int int_quantity_air = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_air = Integer.parseInt(quantity_air)+get_quantity_air;

                    i.putExtra("quantity_air1", int_quantity_air);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                    startActivity(i);
                }

                else if(opsi == 1){
                    String quantity_apel = quantity.getText().toString();
                    int int_quantity_apel = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_apel = Integer.parseInt(quantity_apel)+get_quantity_apel;

                    i.putExtra("quantity_apel1", int_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                    startActivity(i);
                }

                else if(opsi == 2){
                    String quantity_mangga = quantity.getText().toString();
                    int int_quantity_mangga = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_mangga = Integer.parseInt(quantity_mangga)+get_quantity_mangga;

                    i.putExtra("quantity_mangga1", int_quantity_mangga);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                    startActivity(i);
                }

                else{
                    String quantity_alpukat = quantity.getText().toString();
                    int int_quantity_alpukat = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_alpukat = Integer.parseInt(quantity_alpukat)+get_quantity_alpukat;

                    i.putExtra("quantity_alpukat1", int_quantity_alpukat);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_air1", get_quantity_air);
                    startActivity(i);
                }
            }
        });
    }

    public void showReorder(View view){
        Button btn6 = (Button) findViewById(R.id.reorder);
        btn6.setOnClickListener(new View.OnClickListener() {
            Intent intent = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = intent.getIntExtra("option", 0);
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Order.this,MenuDrink.class);
                Intent i1 = getIntent();
                if(opsi == 0){
                    String quantity_air = quantity.getText().toString();
                    int int_quantity_air = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_air = Integer.parseInt(quantity_air)+get_quantity_air;

                    i.putExtra("quantity_air1", int_quantity_air);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else if(opsi == 1){
                    String quantity_apel = quantity.getText().toString();
                    int int_quantity_apel = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_apel = Integer.parseInt(quantity_apel)+get_quantity_apel;

                    i.putExtra("quantity_apel1", int_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else if(opsi == 2){
                    String quantity_mangga = quantity.getText().toString();
                    int int_quantity_mangga = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_mangga = Integer.parseInt(quantity_mangga)+get_quantity_mangga;

                    i.putExtra("quantity_mangga1", int_quantity_mangga);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_air1", get_quantity_air);
                    i.putExtra("quantity_alpukat1", get_quantity_alpukat);
                }

                else{
                    String quantity_alpukat = quantity.getText().toString();
                    int int_quantity_alpukat = 0;
                    int get_quantity_air = i1.getIntExtra("quantity_air", 0);
                    int get_quantity_apel = i1.getIntExtra("quantity_apel", 0);
                    int get_quantity_mangga = i1.getIntExtra("quantity_mangga", 0);
                    int get_quantity_alpukat = i1.getIntExtra("quantity_alpukat", 0);

                    int_quantity_alpukat = Integer.parseInt(quantity_alpukat)+get_quantity_alpukat;

                    i.putExtra("quantity_alpukat1", int_quantity_alpukat);
                    i.putExtra("quantity_apel1", get_quantity_apel);
                    i.putExtra("quantity_mangga1", get_quantity_mangga);
                    i.putExtra("quantity_air1", get_quantity_air);
                }
                startActivity(i);
            }
        });
    }
}