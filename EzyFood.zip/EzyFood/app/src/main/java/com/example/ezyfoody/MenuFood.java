package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MenuFood extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_food);
    }


    // FUNGSI showMyOrder1 tidak bisa jalan karena onclick pada orderButton1 tidak berfungsi
    public void showMyOrder1(View view){
        Button btn2 = (Button) findViewById(R.id.orderButton1);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,MyOrder.class);
                Intent i1 = getIntent();

                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                startActivity(i);
            }
        });
    }

    public void showMyOrder_alter(View view){
        Button btn2 = (Button) findViewById(R.id.orderAlternativeButton);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,MyOrder.class);
                Intent i1 = getIntent();
                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                startActivity(i);
            }
        });
    }

    public void showNoodle(View view){
        ImageView img  = (ImageView) findViewById(R.id.miegoreng);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,FoodOrder.class);
                Intent i1 = getIntent();

                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                i.putExtra("option", 0);
                startActivity(i);
            }
        });
    }

    public void showHakao(View view){
        ImageView img1 = (ImageView) findViewById(R.id.hakao);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,FoodOrder.class);
                Intent i1 = getIntent();

                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                i.putExtra("option", 1);
                startActivity(i);
            }
        });
    }

    public void showShumai(View view){
        ImageView img2 = (ImageView) findViewById(R.id.siomay);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,FoodOrder.class);
                Intent i1 = getIntent();

                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                i.putExtra("option", 2);
                startActivity(i);
            }
        });
    }

    public void showFriedRice(View view){
        ImageView img3 = (ImageView) findViewById(R.id.nasigoreng);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuFood.this,FoodOrder.class);
                Intent i1 = getIntent();

                int quantity_miegoreng = i1.getIntExtra("quantity_miegoreng1", 0);
                int quantity_hakao = i1.getIntExtra("quantity_hakao1", 0);
                int quantity_siomay = i1.getIntExtra("quantity_siomay1", 0);
                int quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng1", 0);

                i.putExtra("quantity_miegoreng", quantity_miegoreng);
                i.putExtra("quantity_hakao", quantity_hakao);
                i.putExtra("quantity_siomai", quantity_siomay);
                i.putExtra("quantity_nasigoreng", quantity_nasigoreng);
                i.putExtra("option", 3);
                startActivity(i);
            }
        });
    }
}