package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Vector;

public class MenuDrink extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_drink);
    }

// FUNGSI showMyOrder1 tidak bisa jalan karena onclick pada orderButton1 tidak berfungsi
    public void showMyOrder1(View view){
        Button btn2 = (Button) findViewById(R.id.orderButton1);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,MyOrder.class);
                Intent i1 = getIntent();

                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);

                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                startActivity(i);
            }
        });
    }

    public void showMyOrder_alter(View view){
        Button btn2 = (Button) findViewById(R.id.orderAlternativeButton);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,MyOrder.class);
                Intent i1 = getIntent();
                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);

                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                startActivity(i);
            }
        });
    }

    public void showAir(View view){
        ImageView img  = (ImageView) findViewById(R.id.aqua);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,Order.class);
                Intent i1 = getIntent();

                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);

                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                i.putExtra("option", 0);
                startActivity(i);
            }
        });
    }

    public void showJusApel(View view){
        ImageView img1 = (ImageView) findViewById(R.id.apel);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,Order.class);
                Intent i1 = getIntent();

                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);


                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                i.putExtra("option", 1);
                startActivity(i);
            }
        });
    }

    public void showJusMangga(View view){
        ImageView img2 = (ImageView) findViewById(R.id.mangga);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,Order.class);
                Intent i1 = getIntent();

                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);


                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                i.putExtra("option", 2);
                startActivity(i);
            }
        });
    }

    public void showJusAlpukat(View view){
        ImageView img3 = (ImageView) findViewById(R.id.alpukat);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuDrink.this,Order.class);
                Intent i1 = getIntent();

                int quantity_air = i1.getIntExtra("quantity_air1", 0);
                int quantity_apel = i1.getIntExtra("quantity_apel1", 0);
                int quantity_mangga = i1.getIntExtra("quantity_mangga1", 0);
                int quantity_alpukat = i1.getIntExtra("quantity_alpukat1", 0);


                i.putExtra("quantity_air", quantity_air);
                i.putExtra("quantity_apel", quantity_apel);
                i.putExtra("quantity_mangga", quantity_mangga);
                i.putExtra("quantity_alpukat", quantity_alpukat);
                i.putExtra("option", 3);
                startActivity(i);
            }
        });
    }

}