package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MenuSnack extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_snack);
    }

    // FUNGSI showMyOrder1 tidak bisa jalan karena onclick pada orderButton1 tidak berfungsi
    public void showMyOrder1(View view){
        Button btn2 = (Button) findViewById(R.id.orderButton1);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,MyOrder.class);
                Intent i1 = getIntent();

                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                startActivity(i);
            }
        });
    }

    public void showMyOrder_alter(View view){
        Button btn2 = (Button) findViewById(R.id.orderAlternativeButton);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,MyOrder.class);
                Intent i1 = getIntent();
                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                startActivity(i);
            }
        });
    }

    public void showPotatoChips(View view){
        ImageView img  = (ImageView) findViewById(R.id.potatochips);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,SnackOrder.class);
                Intent i1 = getIntent();

                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                i.putExtra("option", 0);
                startActivity(i);
            }
        });
    }

    public void showNachos(View view){
        ImageView img1 = (ImageView) findViewById(R.id.nachos);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,SnackOrder.class);
                Intent i1 = getIntent();

                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                i.putExtra("option", 1);
                startActivity(i);
            }
        });
    }

    public void showChickenSkin(View view){
        ImageView img2 = (ImageView) findViewById(R.id.chickenskin);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,SnackOrder.class);
                Intent i1 = getIntent();

                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                i.putExtra("option", 2);
                startActivity(i);
            }
        });
    }

    public void showChasewNut(View view){
        ImageView img3 = (ImageView) findViewById(R.id.chasewnut);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuSnack.this,SnackOrder.class);
                Intent i1 = getIntent();

                int quantity_potato = i1.getIntExtra("quantity_potato1", 0);
                int quantity_nachos = i1.getIntExtra("quantity_nachos1", 0);
                int quantity_chicken = i1.getIntExtra("quantity_chicken1", 0);
                int quantity_chasew = i1.getIntExtra("quantity_chasew1", 0);

                i.putExtra("quantity_potato", quantity_potato);
                i.putExtra("quantity_nachos", quantity_nachos);
                i.putExtra("quantity_chicken", quantity_chicken);
                i.putExtra("quantity_chasew", quantity_chasew);
                i.putExtra("option", 3);
                startActivity(i);
            }
        });
    }

}