package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FoodOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_order);

        CardView card  = (CardView) findViewById(R.id.order_miegoreng);
        CardView card1 = (CardView) findViewById(R.id.order_hakao);
        CardView card2 = (CardView) findViewById(R.id.order_siomay);
        CardView card3 = (CardView) findViewById(R.id.order_nasigoreng);

        Intent intent = getIntent();
        Integer opsi = intent.getIntExtra("option", 0);

        if(opsi == 0){
            card.setVisibility(View.VISIBLE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 1){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.VISIBLE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 2){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.VISIBLE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 3){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.VISIBLE);
        }
    }

    public void showMyOrder2(View view){
        Button btn3 = (Button) findViewById(R.id.orderButton3);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(FoodOrder.this, MyFoodOrder.class);

                if(opsi == 0){
                    String quantity_miegoreng = quantity.getText().toString();
                    int int_quantity_miegoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_miegoreng = Integer.parseInt(quantity_miegoreng)+get_quantity_miegoreng;

                    i.putExtra("quantity_miegoreng1", int_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 1){
                    String quantity_hakao = quantity.getText().toString();
                    int int_quantity_hakao = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_hakao = Integer.parseInt(quantity_hakao)+get_quantity_hakao;

                    i.putExtra("quantity_hakao1", int_quantity_hakao);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 2){
                    String quantity_siomay = quantity.getText().toString();
                    int int_quantity_siomay = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_siomay = Integer.parseInt(quantity_siomay)+get_quantity_siomay;

                    i.putExtra("quantity_siomay1", int_quantity_siomay);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else{
                    String quantity_nasigoreng = quantity.getText().toString();
                    int int_quantity_nasigoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_nasigoreng = Integer.parseInt(quantity_nasigoreng)+get_quantity_nasigoreng;

                    i.putExtra("quantity_nasigoreng1", int_quantity_nasigoreng);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                }
                startActivity(i);
            }
        });
    }

    public void showMyAlternativeOrder(View view){
        Button btn3 = (Button) findViewById(R.id.orderAlternativeButton2);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(FoodOrder.this, MyFoodOrder.class);
                if(opsi == 0){
                    String quantity_miegoreng = quantity.getText().toString();
                    int int_quantity_miegoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_miegoreng = Integer.parseInt(quantity_miegoreng)+get_quantity_miegoreng;

                    i.putExtra("quantity_miegoreng1", int_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 1){
                    String quantity_hakao = quantity.getText().toString();
                    int int_quantity_hakao = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_hakao = Integer.parseInt(quantity_hakao)+get_quantity_hakao;

                    i.putExtra("quantity_hakao1", int_quantity_hakao);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 2){
                    String quantity_siomay = quantity.getText().toString();
                    int int_quantity_siomay = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_siomay = Integer.parseInt(quantity_siomay)+get_quantity_siomay;

                    i.putExtra("quantity_siomay1", int_quantity_siomay);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else{
                    String quantity_nasigoreng = quantity.getText().toString();
                    int int_quantity_nasigoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_nasigoreng = Integer.parseInt(quantity_nasigoreng)+get_quantity_nasigoreng;

                    i.putExtra("quantity_nasigoreng1", int_quantity_nasigoreng);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                }
                startActivity(i);
            }
        });
    }

    public void showReorder(View view){
        Button btn6 = (Button) findViewById(R.id.reorder);
        btn6.setOnClickListener(new View.OnClickListener() {
            Intent intent = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = intent.getIntExtra("option", 0);
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FoodOrder.this,MenuFood.class);
                Intent i1 = getIntent();
                if(opsi == 0){
                    String quantity_miegoreng = quantity.getText().toString();
                    int int_quantity_miegoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_miegoreng = Integer.parseInt(quantity_miegoreng)+get_quantity_miegoreng;

                    i.putExtra("quantity_miegoreng1", int_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 1){
                    String quantity_hakao = quantity.getText().toString();
                    int int_quantity_hakao = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_hakao = Integer.parseInt(quantity_hakao)+get_quantity_hakao;

                    i.putExtra("quantity_hakao1", int_quantity_hakao);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else if(opsi == 2){
                    String quantity_siomay = quantity.getText().toString();
                    int int_quantity_siomay = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_siomay = Integer.parseInt(quantity_siomay)+get_quantity_siomay;

                    i.putExtra("quantity_siomay1", int_quantity_siomay);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_nasigoreng1", get_quantity_nasigoreng);
                }

                else{
                    String quantity_nasigoreng = quantity.getText().toString();
                    int int_quantity_nasigoreng = 0;
                    int get_quantity_miegoreng = i1.getIntExtra("quantity_miegoreng", 0);
                    int get_quantity_hakao = i1.getIntExtra("quantity_hakao", 0);
                    int get_quantity_siomay = i1.getIntExtra("quantity_siomay", 0);
                    int get_quantity_nasigoreng = i1.getIntExtra("quantity_nasigoreng", 0);

                    int_quantity_nasigoreng = Integer.parseInt(quantity_nasigoreng)+get_quantity_nasigoreng;

                    i.putExtra("quantity_nasigoreng1", int_quantity_nasigoreng);
                    i.putExtra("quantity_miegoreng1", get_quantity_miegoreng);
                    i.putExtra("quantity_hakao1", get_quantity_hakao);
                    i.putExtra("quantity_siomay1", get_quantity_siomay);
                }
                startActivity(i);
            }
        });
    }
}