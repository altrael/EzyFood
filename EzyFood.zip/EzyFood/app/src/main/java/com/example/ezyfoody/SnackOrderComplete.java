package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SnackOrderComplete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snack_order_complete);
        Intent i = getIntent();
        String total_harga =i.getStringExtra("total_harga");
        String quantity_potato = i.getStringExtra("harga_potato");
        String quantity_nachos = i.getStringExtra("harga_nachos");
        String quantity_chicken = i.getStringExtra("harga_chicken");
        String quantity_chasew = i.getStringExtra("harga_chasew");

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        total.setText(total_harga);

        // Potato Chips
        TextView potato = (TextView) findViewById(R.id.qtypotato);
        potato.setText(quantity_potato);

        // Nachos
        TextView nachos = (TextView) findViewById(R.id.qtynachos);
        nachos.setText(quantity_nachos);

        // Chicken Skin
        TextView chicken = (TextView) findViewById(R.id.qtychicken);
        chicken.setText(quantity_chicken);

        // Chasew Nut
        TextView chasew = (TextView) findViewById(R.id.qtychasew);
        chasew.setText(quantity_chasew);
    }

    public void showMain(View view){
        Button btn5 = (Button) findViewById(R.id.mainButton);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SnackOrderComplete.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}