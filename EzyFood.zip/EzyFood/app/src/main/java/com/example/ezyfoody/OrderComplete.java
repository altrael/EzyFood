package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OrderComplete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_complete);
        Intent i = getIntent();
        String total_harga =i.getStringExtra("total_harga");
        String quantity_air = i.getStringExtra("harga_air");
        String quantity_apel = i.getStringExtra("harga_apel");
        String quantity_mangga = i.getStringExtra("harga_mangga");
        String quantity_alpukat = i.getStringExtra("harga_alpukat");

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        total.setText(total_harga);

        // Air
        TextView air = (TextView) findViewById(R.id.qtyair);
        air.setText(quantity_air);

        // Jus Apel
        TextView apel = (TextView) findViewById(R.id.qtyapel);
        apel.setText(quantity_apel);

        // Jus Mangga
        TextView mangga = (TextView) findViewById(R.id.qtymangga);
        mangga.setText(quantity_mangga);

        // Jus Alpukat
        TextView alpukat = (TextView) findViewById(R.id.qtymangga2);
        alpukat.setText(quantity_alpukat);
    }

    public void showMain(View view){
        Button btn5 = (Button) findViewById(R.id.mainButton);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(OrderComplete.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}