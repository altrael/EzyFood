package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class TopUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up);

        Intent i = getIntent();
        String saldo = i.getStringExtra("saldo1");
        TextView balance = (TextView) findViewById(R.id.saldotext);
        balance.setText(saldo);
    }

    public void showTopUp(View view){
        Button topupbtn = (Button) findViewById(R.id.topupBtn);
        topupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nominal  = (EditText) findViewById(R.id.topup);
                TextView saldo = (TextView) findViewById(R.id.saldotext);
                String nominals = nominal.getText().toString();
                String saldos = saldo.getText().toString();
                if(saldos.isEmpty()){
                    saldos = "0";
                }
                int int_nominal = Integer.parseInt(nominals) + Integer.parseInt(saldos);

                String balance = String.valueOf(int_nominal);
                saldo.setText(balance);
            }
        });
    }

    public void showMain(View view){
        Button btn5 = (Button) findViewById(R.id.mainButton);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TopUp.this,MainActivity.class);

                TextView balance = (TextView) findViewById(R.id.saldotext);
                String saldo = balance.getText().toString();
                i.putExtra("saldo", saldo);
                startActivity(i);
            }
        });
    }

}