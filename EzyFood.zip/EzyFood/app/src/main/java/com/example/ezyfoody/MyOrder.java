package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);
        Intent i = getIntent();
        int quantity_air = i.getIntExtra("quantity_air1", 0);
        int quantity_apel = i.getIntExtra("quantity_apel1", 0);
        int quantity_mangga = i.getIntExtra("quantity_mangga1", 0);
        int quantity_alpukat = i.getIntExtra("quantity_alpukat1", 0);

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        int total_harga = (quantity_air*6000) + (quantity_apel*10000) + (quantity_mangga*12000) + (quantity_alpukat*12000);

        String Total = "Total = Rp. "+total_harga;
        total.setText(Total);

        // Air
        TextView air = findViewById(R.id.qtyair);
        String aer = "Qty "+quantity_air+" x 6000";
        air.setText(aer);

        // Jus Apel
        TextView apel = findViewById(R.id.qtyapel);
        String apple = "Qty "+quantity_apel+" x 10000";
        apel.setText(apple);

        // Jus Mangga
        TextView mangga = findViewById(R.id.qtymangga);
        String mango = "Qty "+quantity_mangga+" x 12000";
        mangga.setText(mango);

        // Jus Alpukat
        TextView alpukat = findViewById(R.id.qtymangga2);
        String avocado = "Qty "+quantity_alpukat+" x 12000";
        alpukat.setText(avocado);

        // Button Hapus

        Button hapus_air = (Button) findViewById(R.id.hapusair);
        Button hapus_apel = (Button) findViewById(R.id.button2);
        Button hapus_mangga= (Button) findViewById(R.id.hapusmangga);
        Button hapus_alpukat = (Button) findViewById(R.id.hapusalpukat);

        hapus_air.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_air = 0;
                TextView air = (TextView) findViewById(R.id.qtyair);
                String aer = "Qty "+quantity_air+" x 6000";
                air.setText(aer);

            }
        });
        hapus_apel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_apel = 0;
                TextView apel = (TextView) findViewById(R.id.qtyapel);
                String apple = "Qty "+quantity_apel+" x 10000";
                apel.setText(apple);
            }
        });

        hapus_mangga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_mangga = 0;
                TextView mangga = (TextView) findViewById(R.id.qtymangga);
                String mango = "Qty "+quantity_mangga+" x 12000";
                mangga.setText(mango);
            }
        });

        hapus_alpukat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                int quantity_alpukat = 0;
                TextView alpukat = (TextView) findViewById(R.id.qtymangga2);
                String avocado = "Qty "+quantity_alpukat+" x 12000";
                alpukat.setText(avocado);
            }
        });
    }

    public void showMyOrderComplete(View view){
        Button btn4 = (Button) findViewById(R.id.payButton);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MyOrder.this,OrderComplete.class);
                TextView air = (TextView) findViewById(R.id.qtyair);
                TextView apel = (TextView) findViewById(R.id.qtyapel);
                TextView mangga = (TextView) findViewById(R.id.qtymangga);
                TextView alpukat = (TextView) findViewById(R.id.qtymangga2);

                TextView total = (TextView) findViewById(R.id.textView_total);

                i.putExtra("harga_air", air.getText());
                i.putExtra("harga_apel", apel.getText());
                i.putExtra("harga_mangga", mangga.getText());
                i.putExtra("harga_alpukat", alpukat.getText());

                i.putExtra("total_harga", total.getText());
                startActivity(i);
            }
        });
    }
}