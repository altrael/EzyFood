package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SnackOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snack_order);

        CardView card  = (CardView) findViewById(R.id.order_potatochips);
        CardView card1 = (CardView) findViewById(R.id.order_nachos);
        CardView card2 = (CardView) findViewById(R.id.order_chickenskin);
        CardView card3 = (CardView) findViewById(R.id.order_chasewnut);

        Intent intent = getIntent();
        Integer opsi = intent.getIntExtra("option", 0);

        if(opsi == 0){
            card.setVisibility(View.VISIBLE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 1){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.VISIBLE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 2){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.VISIBLE);
            card3.setVisibility(View.GONE);
        }

        else if(opsi == 3){
            card.setVisibility(View.GONE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.VISIBLE);
        }
    }

    public void showMyOrder2(View view){
        Button btn3 = (Button) findViewById(R.id.orderButton3);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(SnackOrder.this, MySnackOrder.class);

                if(opsi == 0){
                    String quantity_potato = quantity.getText().toString();
                    int int_quantity_potato = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_potato = Integer.parseInt(quantity_potato)+get_quantity_potato;

                    i.putExtra("quantity_potato1", int_quantity_potato);
                    i.putExtra("quantity_nacho1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 1){
                    String quantity_nachos = quantity.getText().toString();
                    int int_quantity_nachos = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_nachos = Integer.parseInt(quantity_nachos)+get_quantity_nachos;

                    i.putExtra("quantity_nachos1", int_quantity_nachos);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 2){
                    String quantity_chicken = quantity.getText().toString();
                    int int_quantity_chicken = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chicken = Integer.parseInt(quantity_chicken)+get_quantity_chicken;

                    i.putExtra("quantity_chicken1", int_quantity_chicken);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else{
                    String quantity_chasew = quantity.getText().toString();
                    int int_quantity_chasew = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chasew = Integer.parseInt(quantity_chasew)+get_quantity_chasew;

                    i.putExtra("quantity_chasew1", int_quantity_chasew);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                }
                startActivity(i);
            }
        });
    }

    public void showMyAlternativeOrder(View view){
        Button btn3 = (Button) findViewById(R.id.orderAlternativeButton2);
        btn3.setOnClickListener(new View.OnClickListener() {
            Intent i1 = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = i1.getIntExtra("option", 0);

            @Override
            public void onClick(View v) {
                Intent i = new Intent(SnackOrder.this, MySnackOrder.class);
                if(opsi == 0){
                    String quantity_potato = quantity.getText().toString();
                    int int_quantity_potato = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_potato = Integer.parseInt(quantity_potato)+get_quantity_potato;

                    i.putExtra("quantity_potato1", int_quantity_potato);
                    i.putExtra("quantity_nacho1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 1){
                    String quantity_nachos = quantity.getText().toString();
                    int int_quantity_nachos = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_nachos = Integer.parseInt(quantity_nachos)+get_quantity_nachos;

                    i.putExtra("quantity_nachos1", int_quantity_nachos);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 2){
                    String quantity_chicken = quantity.getText().toString();
                    int int_quantity_chicken = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chicken = Integer.parseInt(quantity_chicken)+get_quantity_chicken;

                    i.putExtra("quantity_chicken1", int_quantity_chicken);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else{
                    String quantity_chasew = quantity.getText().toString();
                    int int_quantity_chasew = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chasew = Integer.parseInt(quantity_chasew)+get_quantity_chasew;

                    i.putExtra("quantity_chasew1", int_quantity_chasew);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                }
                    startActivity(i);
            }
        });
    }

    public void showReorder(View view){
        Button btn6 = (Button) findViewById(R.id.reorder);
        btn6.setOnClickListener(new View.OnClickListener() {
            Intent intent = getIntent();
            EditText quantity  = (EditText) findViewById(R.id.quantity);
            Integer opsi = intent.getIntExtra("option", 0);
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SnackOrder.this,MenuSnack.class);
                Intent i1 = getIntent();
                if(opsi == 0){
                    String quantity_potato = quantity.getText().toString();
                    int int_quantity_potato = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_potato = Integer.parseInt(quantity_potato)+get_quantity_potato;

                    i.putExtra("quantity_potato1", int_quantity_potato);
                    i.putExtra("quantity_nacho1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 1){
                    String quantity_nachos = quantity.getText().toString();
                    int int_quantity_nachos = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_nachos = Integer.parseInt(quantity_nachos)+get_quantity_nachos;

                    i.putExtra("quantity_nachos1", int_quantity_nachos);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else if(opsi == 2){
                    String quantity_chicken = quantity.getText().toString();
                    int int_quantity_chicken = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chicken = Integer.parseInt(quantity_chicken)+get_quantity_chicken;

                    i.putExtra("quantity_chicken1", int_quantity_chicken);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chasew1", get_quantity_chasew);
                }

                else{
                    String quantity_chasew = quantity.getText().toString();
                    int int_quantity_chasew = 0;
                    int get_quantity_potato = i1.getIntExtra("quantity_potato", 0);
                    int get_quantity_nachos = i1.getIntExtra("quantity_nachos", 0);
                    int get_quantity_chicken = i1.getIntExtra("quantity_chicken", 0);
                    int get_quantity_chasew = i1.getIntExtra("quantity_chasew", 0);

                    int_quantity_chasew = Integer.parseInt(quantity_chasew)+get_quantity_chasew;

                    i.putExtra("quantity_chasew1", int_quantity_chasew);
                    i.putExtra("quantity_potato1", get_quantity_potato);
                    i.putExtra("quantity_nachos1", get_quantity_nachos);
                    i.putExtra("quantity_chicken1", get_quantity_chicken);
                }
                startActivity(i);
            }
        });
    }

}