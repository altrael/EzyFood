package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FoodOrderComplete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_order_complete);
        Intent i = getIntent();
        String total_harga =i.getStringExtra("total_harga");
        String quantity_miegoreng = i.getStringExtra("harga_miegoreng");
        String quantity_hakao = i.getStringExtra("harga_hakao");
        String quantity_siomay = i.getStringExtra("harga_siomay");
        String quantity_nasigoreng = i.getStringExtra("harga_nasigoreng");

        // Total Harga
        TextView total = (TextView) findViewById(R.id.textView_total);
        total.setText(total_harga);

        // Mie Goreng
        TextView miegoreng = (TextView) findViewById(R.id.qtymiegoreng);
        miegoreng.setText(quantity_miegoreng);

        // Hakao
        TextView hakao = (TextView) findViewById(R.id.qtyhakao);
        hakao.setText(quantity_hakao);

        // Siomay
        TextView siomay = (TextView) findViewById(R.id.qtysiomay);
        siomay.setText(quantity_siomay);

        // Nasi Goreng
        TextView nasigoreng = (TextView) findViewById(R.id.qtynasigoreng);
        nasigoreng.setText(quantity_nasigoreng);
    }

    public void showMain(View view){
        Button btn5 = (Button) findViewById(R.id.mainButton);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FoodOrderComplete.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}